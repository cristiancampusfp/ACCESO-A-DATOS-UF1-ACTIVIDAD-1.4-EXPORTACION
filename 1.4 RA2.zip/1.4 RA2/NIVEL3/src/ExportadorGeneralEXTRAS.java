import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

// Esta clase sirve para hacer una exportación "general" de reservas con opciones extras
public class ExportadorGeneralEXTRAS {

    // Carpeta donde se guardan los archivos
    private static final String DIRECTORIO = "exportaciones";

    /**
     * Método principal para exportar reservas con filtros, orden y compresión ZIP
     *
     * @param reservas Lista de reservas
     * @param exportCSV Si se quiere exportar CSV
     * @param exportXML Si se quiere exportar XML
     * @param exportJSON Si se quiere exportar JSON
     * @param desde Fecha mínima para filtrar reservas
     * @param hasta Fecha máxima para filtrar reservas
     * @param estadoFiltro Filtrar por estado ("Confirmada", "Cancelada", etc.)
     * @param clienteFiltro Filtrar por cliente específico
     * @param ordenarPorFechaEntrada Si se ordena por fecha de entrada
     */
    public static boolean exportar(ArrayList<Reserva> reservas,
                                   boolean exportCSV,
                                   boolean exportXML,
                                   boolean exportJSON,
                                   LocalDate desde,
                                   LocalDate hasta,
                                   String estadoFiltro,
                                   Cliente clienteFiltro,
                                   boolean ordenarPorFechaEntrada) {

        // Verifico que haya reservas
        if (reservas == null || reservas.isEmpty()) {
            System.out.println("❌ ERROR: No hay reservas para exportar.");
            return false;
        }

        // Filtrar reservas según los parámetros dados
        ArrayList<Reserva> filtradas = new ArrayList<>();
        for (Reserva r : reservas) {
            boolean cumple = true;

            if (desde != null && r.getFechaEntrada().isBefore(desde)) cumple = false;
            if (hasta != null && r.getFechaSalida().isAfter(hasta)) cumple = false;
            if (estadoFiltro != null && !estadoFiltro.isEmpty() && !r.getEstado().equalsIgnoreCase(estadoFiltro))
                cumple = false;
            if (clienteFiltro != null && r.getCliente().getId() != clienteFiltro.getId()) cumple = false;

            if (cumple) filtradas.add(r); // solo agrego si cumple los filtros
        }

        // Ordenar por fecha de entrada si corresponde
        if (ordenarPorFechaEntrada) {
            filtradas.sort(Comparator.comparing(Reserva::getFechaEntrada));
        }

        // Crear carpeta si no existe
        File dir = new File(DIRECTORIO);
        if (!dir.exists()) dir.mkdir();

        // Genero un timestamp para poner en los nombres de archivo
        String timestamp = LocalDate.now().format(DateTimeFormatter.BASIC_ISO_DATE);
        ArrayList<String> archivosExportados = new ArrayList<>();

        try {
            // Exportar CSV si se pidió
            if (exportCSV) {
                String nombreCSV = "reservas_" + timestamp; // nombre base
                if (ExportadorCSV.exportar(filtradas, nombreCSV))
                    archivosExportados.add(DIRECTORIO + File.separator + nombreCSV + ".csv");
            }

            // Exportar XML si se pidió
            if (exportXML) {
                String nombreXML = "reservas_" + timestamp;
                if (ExportadorXML.exportar(filtradas, nombreXML))
                    archivosExportados.add(DIRECTORIO + File.separator + nombreXML + ".xml");
            }

            // Exportar JSON si se pidió
            if (exportJSON) {
                String nombreJSON = "reservas_" + timestamp;
                if (ExportadorJSON.exportar(filtradas, nombreJSON))
                    archivosExportados.add(DIRECTORIO + File.separator + nombreJSON + ".json");
            }

            // Si hay archivos exportados, los comprimo en un ZIP
            if (!archivosExportados.isEmpty()) {
                String zipName = DIRECTORIO + File.separator + "exportacion_" + timestamp + ".zip";
                try (ZipOutputStream zipOut = new ZipOutputStream(new FileOutputStream(zipName))) {
                    for (String ruta : archivosExportados) {
                        File archivo = new File(ruta);
                        try (FileInputStream fis = new FileInputStream(archivo)) {
                            ZipEntry entry = new ZipEntry(archivo.getName());
                            zipOut.putNextEntry(entry);

                            byte[] buffer = new byte[1024];
                            int len;
                            while ((len = fis.read(buffer)) > 0) {
                                zipOut.write(buffer, 0, len);
                            }

                            zipOut.closeEntry();
                        }
                    }
                }
                System.out.println("✅ Archivos comprimidos en ZIP: " + zipName);
            }

            System.out.println("✅ Exportación general completada.");
            return true;

        } catch (IOException e) {
            System.out.println("❌ ERROR en exportación: " + e.getMessage());
            return false;
        }
    }

    // ─────────────── MAIN DE PRUEBA ───────────────
    public static void main(String[] args) {

        // Creo clientes
        Cliente c1 = new Cliente(1, "Juan García", "juan@email.com", "666111222");
        Cliente c2 = new Cliente(2, "María López", "maria@email.com", "666333444");

        // Creo habitaciones
        Habitacion h101 = new Habitacion(101, "Doble", 90.0, false);
        Habitacion h205 = new Habitacion(205, "Suite", 200.0, true);

        // Creo reservas
        ArrayList<Reserva> reservas = new ArrayList<>();
        reservas.add(new Reserva(1, c1, h101, java.time.LocalDate.parse("2025-10-20"),
                java.time.LocalDate.parse("2025-10-23"), 3, 270.0, "Confirmada"));
        reservas.add(new Reserva(2, c2, h205, java.time.LocalDate.parse("2025-10-21"),
                java.time.LocalDate.parse("2025-10-25"), 4, 800.0, "Confirmada"));
        reservas.add(new Reserva(3, c1, h205, java.time.LocalDate.parse("2025-11-01"),
                java.time.LocalDate.parse("2025-11-05"), 4, 800.0, "Completada"));
        reservas.add(new Reserva(4, c2, h101, java.time.LocalDate.parse("2025-12-01"),
                java.time.LocalDate.parse("2025-12-03"), 2, 180.0, "Cancelada"));

        // Llamada de prueba: solo reservas del cliente c1, estado "Confirmada", ordenadas por fecha
        boolean exito = ExportadorGeneralEXTRAS.exportar(
                reservas,
                true,   // exportar CSV
                true,   // exportar XML
                true,   // exportar JSON
                java.time.LocalDate.parse("2025-10-01"), // desde
                java.time.LocalDate.parse("2025-12-31"), // hasta
                "Confirmada", // estado filtro
                c1,     // cliente filtro
                true    // ordenar por fecha entrada
        );

        if (exito) {
            System.out.println("✅ Exportación con filtros y ZIP completada correctamente.");
        } else {
            System.out.println("❌ Fallo en la exportación.");
        }
    }

}
