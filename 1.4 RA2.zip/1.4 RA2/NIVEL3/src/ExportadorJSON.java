import java.io.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;

// Esta clase sirve para exportar las reservas a un archivo JSON
public class ExportadorJSON {

    // Carpeta donde se guardan los archivos
    private static final String DIRECTORIO = "exportaciones";

    // Método principal que exporta la lista de reservas a JSON
    public static boolean exportar(ArrayList<Reserva> reservas, String nombreArchivo) {

        // Primero verifico que haya reservas para exportar
        if (reservas == null || reservas.isEmpty()) {
            System.out.println("❌ ERROR: No hay reservas para exportar.");
            return false;
        }

        // Compruebo que el nombre del archivo no esté vacío
        if (nombreArchivo == null || nombreArchivo.trim().isEmpty()) {
            System.out.println("❌ ERROR: El nombre del archivo no puede estar vacío.");
            return false;
        }

        // Creo la carpeta si no existe
        File dir = new File(DIRECTORIO);
        if (!dir.exists()) dir.mkdir();

        // Ruta completa del archivo JSON
        String rutaCompleta = DIRECTORIO + File.separator + nombreArchivo + ".json";

        // Estructuras para guardar clientes, habitaciones y estadísticas
        HashMap<Integer, Cliente> clientesMap = new HashMap<>();
        HashMap<Integer, Habitacion> habitacionesMap = new HashMap<>();
        HashMap<String, EstadisticaTipo> estadisticasTipo = new HashMap<>();
        HashMap<String, Integer> estadisticasEstado = new HashMap<>();
        int totalReservas = reservas.size();
        double ingresosTotal = 0;
        int nochesTotal = 0;

        // Recorro todas las reservas para preparar los datos
        for (Reserva r : reservas) {
            clientesMap.put(r.getCliente().getId(), r.getCliente());
            habitacionesMap.put(r.getHabitacion().getNumero(), r.getHabitacion());

            // Estadísticas por tipo de habitación
            String tipo = r.getHabitacion().getTipo();
            estadisticasTipo.putIfAbsent(tipo, new EstadisticaTipo());
            EstadisticaTipo estTipo = estadisticasTipo.get(tipo);
            estTipo.totalReservas++;
            estTipo.ingresos += r.getPrecioTotal();

            // Estadísticas por estado
            estadisticasEstado.put(r.getEstado(),
                    estadisticasEstado.getOrDefault(r.getEstado(), 0) + 1);

            // Estadísticas globales
            ingresosTotal += r.getPrecioTotal();
            nochesTotal += r.getNoches();
        }

        // Calculo el porcentaje de reservas por tipo de habitación
        for (EstadisticaTipo et : estadisticasTipo.values()) {
            et.porcentaje = ((double) et.totalReservas / totalReservas) * 100;
        }

        // Escribir el archivo JSON
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(rutaCompleta))) {
            String IND = "  "; // indentación para que quede legible
            writer.write("{\n");
            writer.write(IND + "\"hotel\": {\n");
            writer.write(IND + IND + "\"informacion\": {\n");
            writer.write(IND + IND + IND + "\"nombre\": \"Hotel Paradise\",\n");
            writer.write(IND + IND + IND + "\"fecha\": \"" + LocalDate.now() + "\"\n");
            writer.write(IND + IND + "},\n");

            // Clientes
            writer.write(IND + IND + "\"clientes\": {\n");
            int i = 0;
            for (Cliente c : clientesMap.values()) {
                writer.write(IND + IND + IND + "\"" + c.getId() + "\": {\n");
                writer.write(IND + IND + IND + IND + "\"nombre\": \"" + escaparJSON(c.getNombre()) + "\",\n");
                writer.write(IND + IND + IND + IND + "\"email\": \"" + escaparJSON(c.getEmail()) + "\",\n");
                writer.write(IND + IND + IND + IND + "\"telefono\": \"" + escaparJSON(c.getTelefono()) + "\"\n");
                writer.write(IND + IND + IND + "}" + (++i < clientesMap.size() ? "," : "") + "\n");
            }
            writer.write(IND + IND + "},\n");

            // Habitaciones
            writer.write(IND + IND + "\"habitaciones\": {\n");
            i = 0;
            for (Habitacion h : habitacionesMap.values()) {
                writer.write(IND + IND + IND + "\"" + h.getNumero() + "\": {\n");
                writer.write(IND + IND + IND + IND + "\"tipo\": \"" + escaparJSON(h.getTipo()) + "\",\n");
                writer.write(IND + IND + IND + IND + "\"precioPorNoche\": " + h.getPrecioPorNoche() + ",\n");
                writer.write(IND + IND + IND + IND + "\"disponible\": " + h.isDisponible() + "\n");
                writer.write(IND + IND + IND + "}" + (++i < habitacionesMap.size() ? "," : "") + "\n");
            }
            writer.write(IND + IND + "},\n");

            // Reservas
            writer.write(IND + IND + "\"reservas\": [\n");
            for (i = 0; i < reservas.size(); i++) {
                Reserva r = reservas.get(i);
                writer.write(IND + IND + IND + "{\n");
                writer.write(IND + IND + IND + IND + "\"id\": " + r.getId() + ",\n");
                writer.write(IND + IND + IND + IND + "\"clienteId\": " + r.getCliente().getId() + ",\n");
                writer.write(IND + IND + IND + IND + "\"habitacionNumero\": " + r.getHabitacion().getNumero() + ",\n");
                writer.write(IND + IND + IND + IND + "\"fechaEntrada\": \"" + r.getFechaEntrada() + "\",\n");
                writer.write(IND + IND + IND + IND + "\"fechaSalida\": \"" + r.getFechaSalida() + "\",\n");
                writer.write(IND + IND + IND + IND + "\"noches\": " + r.getNoches() + ",\n");
                writer.write(IND + IND + IND + IND + "\"precioTotal\": " + r.getPrecioTotal() + ",\n");
                writer.write(IND + IND + IND + IND + "\"estado\": \"" + escaparJSON(r.getEstado()) + "\"\n");
                writer.write(IND + IND + IND + "}" + (i < reservas.size() - 1 ? "," : "") + "\n");
            }
            writer.write(IND + IND + "],\n");

            // Estadísticas
            writer.write(IND + IND + "\"estadisticas\": {\n");

            // Por tipo de habitación
            writer.write(IND + IND + IND + "\"porTipoHabitacion\": {\n");
            i = 0;
            for (String tipo : estadisticasTipo.keySet()) {
                EstadisticaTipo et = estadisticasTipo.get(tipo);
                writer.write(IND + IND + IND + IND + "\"" + tipo + "\": {\n");
                writer.write(IND + IND + IND + IND + IND + "\"totalReservas\": " + et.totalReservas + ",\n");
                writer.write(IND + IND + IND + IND + IND + "\"ingresos\": " + et.ingresos + ",\n");
                writer.write(IND + IND + IND + IND + IND + "\"porcentaje\": " + String.format("%.1f", et.porcentaje) + "\n");
                writer.write(IND + IND + IND + IND + "}" + (++i < estadisticasTipo.size() ? "," : "") + "\n");
            }
            writer.write(IND + IND + IND + "},\n");

            // Por estado
            writer.write(IND + IND + IND + "\"porEstado\": {\n");
            i = 0;
            for (String estado : estadisticasEstado.keySet()) {
                writer.write(IND + IND + IND + IND + "\"" + estado + "\": " + estadisticasEstado.get(estado)
                        + (++i < estadisticasEstado.size() ? "," : "") + "\n");
            }
            writer.write(IND + IND + IND + "},\n");

            // Resumen global
            double ocupacionMedia = totalReservas == 0 ? 0 : ((double) nochesTotal / totalReservas);
            writer.write(IND + IND + IND + "\"resumen\": {\n");
            writer.write(IND + IND + IND + IND + "\"totalReservas\": " + totalReservas + ",\n");
            writer.write(IND + IND + IND + IND + "\"ingresosTotal\": " + ingresosTotal + ",\n");
            writer.write(IND + IND + IND + IND + "\"nochesReservadas\": " + nochesTotal + ",\n");
            writer.write(IND + IND + IND + IND + "\"ocupacionMedia\": " + String.format("%.1f", ocupacionMedia) + "\n");
            writer.write(IND + IND + IND + "}\n");

            writer.write(IND + IND + "}\n"); // cierre estadisticas
            writer.write(IND + "}\n"); // cierre hotel
            writer.write("}\n"); // cierre root

            System.out.println("✅ Exportación JSON completada: " + rutaCompleta);
            return true;

        } catch (IOException e) {
            System.out.println("❌ ERROR al escribir JSON: " + e.getMessage());
            return false;
        }
    }

    // Método para escapar caracteres especiales en JSON
    private static String escaparJSON(String texto) {
        if (texto == null) return "";
        return texto.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n");
    }

    // Clase auxiliar para estadísticas por tipo de habitación
    private static class EstadisticaTipo {
        int totalReservas = 0;
        double ingresos = 0;
        double porcentaje = 0;
    }

    // MAIN de prueba
    public static void main(String[] args) {

        Cliente c1 = new Cliente(1, "Juan García", "juan@email.com", "666111222");
        Cliente c2 = new Cliente(2, "María López", "maria@email.com", "666333444");

        Habitacion h101 = new Habitacion(101, "Doble", 90.00, false);
        Habitacion h205 = new Habitacion(205, "Suite", 200.00, true);

        ArrayList<Reserva> reservas = new ArrayList<>();
        reservas.add(new Reserva(1, c1, h101, LocalDate.parse("2025-10-20"), LocalDate.parse("2025-10-23"), 3, 270.00, "Confirmada"));
        reservas.add(new Reserva(2, c2, h205, LocalDate.parse("2025-10-21"), LocalDate.parse("2025-10-25"), 4, 800.00, "Confirmada"));
        reservas.add(new Reserva(3, c1, h205, LocalDate.parse("2025-11-01"), LocalDate.parse("2025-11-05"), 4, 800.00, "Completada"));

        // Llamo al método exportar
        exportar(reservas, "hotel_reservas");
    }
}
