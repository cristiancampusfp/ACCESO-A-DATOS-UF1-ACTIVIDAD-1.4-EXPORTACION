import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;

// Esta clase se encarga de exportar las reservas a un archivo XML
public class ExportadorXML {

    // Indentación para que el XML quede legible y la carpeta donde se guardan los archivos
    private static final String INDENT = "  ";
    private static final String DIRECTORIO = "exportaciones";

    // Método principal que genera el XML
    public static boolean exportar(ArrayList<Reserva> reservas, String nombreArchivo) {
        // Primero compruebo que haya reservas para exportar
        if (reservas == null || reservas.isEmpty()) {
            System.out.println("❌ ERROR: No hay reservas para exportar.");
            return false;
        }

        // Compruebo que el nombre del archivo no esté vacío
        if (nombreArchivo == null || nombreArchivo.trim().isEmpty()) {
            System.out.println("❌ ERROR: El nombre del archivo no puede estar vacío.");
            return false;
        }

        // Creo la carpeta de exportaciones si no existe
        File dir = new File(DIRECTORIO);
        if (!dir.exists()) dir.mkdir();

        // Ruta completa del archivo XML
        String rutaCompleta = DIRECTORIO + File.separator + nombreArchivo + ".xml";
        DateTimeFormatter formatoFecha = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        // Para calcular estadísticas mientras recorro las reservas
        HashMap<String, Integer> estadoCount = new HashMap<>();
        HashMap<String, Double> tipoIngresos = new HashMap<>();
        HashMap<String, Integer> tipoReservas = new HashMap<>();
        int totalNoches = 0;
        double ingresosTotal = 0;

        // Recorro todas las reservas para preparar las estadísticas
        for (Reserva r : reservas) {
            // Cuento cuántas reservas hay por estado
            estadoCount.put(r.getEstado(), estadoCount.getOrDefault(r.getEstado(), 0) + 1);

            // Cuento cuántas reservas hay por tipo de habitación y sus ingresos
            String tipo = r.getHabitacion().getTipo();
            tipoReservas.put(tipo, tipoReservas.getOrDefault(tipo, 0) + 1);
            tipoIngresos.put(tipo, tipoIngresos.getOrDefault(tipo, 0.0) + r.getPrecioTotal());

            totalNoches += r.getNoches();
            ingresosTotal += r.getPrecioTotal();
        }

        // Abro el archivo para escribir
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(rutaCompleta))) {
            // Declaración inicial del XML
            writer.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
            writer.newLine();
            writer.write("<hotel>");
            writer.newLine();

            // Información general del hotel
            writer.write(INDENT + "<informacion>");
            writer.newLine();
            writer.write(INDENT + INDENT + "<nombre>Hotel Paradise</nombre>");
            writer.newLine();
            writer.write(INDENT + INDENT + "<fecha>" + LocalDate.now().format(formatoFecha) + "</fecha>");
            writer.newLine();
            writer.write(INDENT + "</informacion>");
            writer.newLine();

            // Empiezo la sección de reservas
            writer.write(INDENT + "<reservas totalReservas=\"" + reservas.size() + "\">");
            writer.newLine();
            for (Reserva r : reservas) {
                writer.write(INDENT + INDENT + "<reserva id=\"" + r.getId() + "\" estado=\"" + escaparXML(r.getEstado()) + "\">");
                writer.newLine();

                // Información del cliente
                writer.write(INDENT + INDENT + INDENT + "<cliente>");
                writer.newLine();
                writer.write(INDENT + INDENT + INDENT + INDENT + "<id>" + r.getCliente().getId() + "</id>");
                writer.newLine();
                writer.write(INDENT + INDENT + INDENT + INDENT + "<nombre>" + escaparXML(r.getCliente().getNombre()) + "</nombre>");
                writer.newLine();
                writer.write(INDENT + INDENT + INDENT + INDENT + "<email>" + escaparXML(r.getCliente().getEmail()) + "</email>");
                writer.newLine();
                writer.write(INDENT + INDENT + INDENT + INDENT + "<telefono>" + escaparXML(r.getCliente().getTelefono()) + "</telefono>");
                writer.newLine();
                writer.write(INDENT + INDENT + INDENT + "</cliente>");
                writer.newLine();

                // Información de la habitación
                writer.write(INDENT + INDENT + INDENT + "<habitacion numero=\"" + r.getHabitacion().getNumero() +
                        "\" tipo=\"" + escaparXML(r.getHabitacion().getTipo()) + "\">");
                writer.newLine();
                writer.write(INDENT + INDENT + INDENT + INDENT + "<precioPorNoche>" +
                        String.format("%.2f", r.getHabitacion().getPrecioPorNoche()) + "</precioPorNoche>");
                writer.newLine();
                writer.write(INDENT + INDENT + INDENT + INDENT + "<disponible>" + r.getHabitacion().isDisponible() + "</disponible>");
                writer.newLine();
                writer.write(INDENT + INDENT + INDENT + "</habitacion>");
                writer.newLine();

                // Fechas de entrada y salida y número de noches
                writer.write(INDENT + INDENT + INDENT + "<fechas>");
                writer.newLine();
                writer.write(INDENT + INDENT + INDENT + INDENT + "<entrada>" + r.getFechaEntrada().format(formatoFecha) + "</entrada>");
                writer.newLine();
                writer.write(INDENT + INDENT + INDENT + INDENT + "<salida>" + r.getFechaSalida().format(formatoFecha) + "</salida>");
                writer.newLine();
                writer.write(INDENT + INDENT + INDENT + INDENT + "<noches>" + r.getNoches() + "</noches>");
                writer.newLine();
                writer.write(INDENT + INDENT + INDENT + "</fechas>");
                writer.newLine();

                // Precio total y precio por noche
                writer.write(INDENT + INDENT + INDENT + "<precio>");
                writer.newLine();
                writer.write(INDENT + INDENT + INDENT + INDENT + "<total>" + String.format("%.2f", r.getPrecioTotal()) + "</total>");
                writer.newLine();
                writer.write(INDENT + INDENT + INDENT + INDENT + "<porNoche>" + String.format("%.2f", r.getHabitacion().getPrecioPorNoche()) + "</porNoche>");
                writer.newLine();
                writer.write(INDENT + INDENT + INDENT + "</precio>");
                writer.newLine();

                writer.write(INDENT + INDENT + "</reserva>");
                writer.newLine();
            }
            writer.write(INDENT + "</reservas>");
            writer.newLine();

            // Estadísticas generales
            writer.write(INDENT + "<estadisticas>");
            writer.newLine();

            // Estadísticas por tipo de habitación
            writer.write(INDENT + INDENT + "<porTipoHabitacion>");
            writer.newLine();
            for (String tipo : tipoReservas.keySet()) {
                writer.write(INDENT + INDENT + INDENT + "<" + tipo + ">");
                writer.newLine();
                writer.write(INDENT + INDENT + INDENT + INDENT + "<totalReservas>" + tipoReservas.get(tipo) + "</totalReservas>");
                writer.newLine();
                writer.write(INDENT + INDENT + INDENT + INDENT + "<ingresos>" + String.format("%.2f", tipoIngresos.get(tipo)) + "</ingresos>");
                writer.newLine();
                writer.write(INDENT + INDENT + INDENT + "</" + tipo + ">");
                writer.newLine();
            }
            writer.write(INDENT + INDENT + "</porTipoHabitacion>");
            writer.newLine();

            // Estadísticas por estado de la reserva
            writer.write(INDENT + INDENT + "<porEstado>");
            writer.newLine();
            for (String estado : estadoCount.keySet()) {
                writer.write(INDENT + INDENT + INDENT + "<" + estado + ">" + estadoCount.get(estado) + "</" + estado + ">");
                writer.newLine();
            }
            writer.write(INDENT + INDENT + "</porEstado>");
            writer.newLine();

            // Resumen general: total reservas, ingresos y noches reservadas
            writer.write(INDENT + INDENT + "<resumen>");
            writer.newLine();
            writer.write(INDENT + INDENT + INDENT + "<totalReservas>" + reservas.size() + "</totalReservas>");
            writer.newLine();
            writer.write(INDENT + INDENT + INDENT + "<ingresosTotal>" + String.format("%.2f", ingresosTotal) + "</ingresosTotal>");
            writer.newLine();
            writer.write(INDENT + INDENT + INDENT + "<nochesReservadas>" + totalNoches + "</nochesReservadas>");
            writer.newLine();
            writer.write(INDENT + INDENT + "</resumen>");
            writer.newLine();

            writer.write(INDENT + "</estadisticas>");
            writer.newLine();

            // Cierre del XML
            writer.write("</hotel>");
            writer.newLine();

            System.out.println("✅ Exportación XML de reservas completada: " + rutaCompleta);
            return true;

        } catch (IOException ex) {
            System.out.println("❌ ERROR al escribir XML: " + ex.getMessage());
            return false;
        }
    }

    // Método para escapar caracteres que podrían romper el XML
    private static String escaparXML(String texto) {
        if (texto == null) return "";
        return texto.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&apos;");
    }

    // MAIN de prueba para probar el XML
    public static void main(String[] args) {
        ArrayList<Reserva> reservas = new ArrayList<>();

        // Clientes de prueba
        Cliente c1 = new Cliente(1, "Juan García", "juan@email.com", "666111222");
        Cliente c2 = new Cliente(2, "María López", "maria@email.com", "666333444");

        // Habitaciones de prueba
        Habitacion h1 = new Habitacion(101, "Doble", 90.0, false);
        Habitacion h2 = new Habitacion(205, "Suite", 200.0, true);

        // Reservas de ejemplo
        reservas.add(new Reserva(1, c1, h1, LocalDate.parse("2025-10-20"),
                LocalDate.parse("2025-10-23"), 3, 270.0, "Confirmada"));
        reservas.add(new Reserva(2, c2, h2, LocalDate.parse("2025-10-21"),
                LocalDate.parse("2025-10-25"), 4, 800.0, "Confirmada"));

        // Llamo al método exportar
        exportar(reservas, "reservas_hotel_xml");
    }
}
