import java.io.*;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

// Clase encargada de exportar las reservas a un archivo CSV
public class ExportadorCSV {

    // Separador de columnas en el CSV y carpeta donde se guardan los archivos
    private static final String SEPARADOR = ";";
    private static final String DIRECTORIO = "exportaciones";

    // Método principal que hace la exportación
    public static boolean exportar(ArrayList<Reserva> reservas, String nombreArchivo) {
        // Primero compruebo que haya reservas para exportar
        if (reservas == null || reservas.isEmpty()) {
            System.out.println("❌ ERROR: No hay reservas para exportar.");
            return false;
        }

        // Compruebo que el nombre del archivo no esté vacío
        if (nombreArchivo == null || nombreArchivo.trim().isEmpty()) {
            System.out.println("❌ ERROR: El nombre del archivo no puede estar vacío.");
            return false;
        }

        // Creo la carpeta de exportaciones si no existe
        File dir = new File(DIRECTORIO);
        if (!dir.exists()) dir.mkdir();

        // Ruta completa del archivo CSV
        String rutaCompleta = DIRECTORIO + File.separator + nombreArchivo + ".csv";

        // Formato para las fechas en el CSV
        DateTimeFormatter formatoFecha = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(rutaCompleta))) {
            // Escribo la cabecera del CSV
            writer.write("ID" + SEPARADOR +
                    "ClienteNombre" + SEPARADOR +
                    "ClienteEmail" + SEPARADOR +
                    "ClienteTelefono" + SEPARADOR +
                    "HabitacionNum" + SEPARADOR +
                    "TipoHabitacion" + SEPARADOR +
                    "PrecioPorNoche" + SEPARADOR +
                    "Disponible" + SEPARADOR +
                    "FechaEntrada" + SEPARADOR +
                    "FechaSalida" + SEPARADOR +
                    "Noches" + SEPARADOR +
                    "PrecioTotal" + SEPARADOR +
                    "Estado");
            writer.newLine(); // salto de línea después del encabezado

            // Recorro todas las reservas y las escribo una a una
            for (Reserva r : reservas) {
                writer.write(r.getId() + SEPARADOR +
                        escaparCSV(r.getCliente().getNombre()) + SEPARADOR +
                        escaparCSV(r.getCliente().getEmail()) + SEPARADOR +
                        escaparCSV(r.getCliente().getTelefono()) + SEPARADOR +
                        r.getHabitacion().getNumero() + SEPARADOR +
                        escaparCSV(r.getHabitacion().getTipo()) + SEPARADOR +
                        String.format("%.2f", r.getHabitacion().getPrecioPorNoche()) + SEPARADOR +
                        r.getHabitacion().isDisponible() + SEPARADOR +
                        r.getFechaEntrada().format(formatoFecha) + SEPARADOR +
                        r.getFechaSalida().format(formatoFecha) + SEPARADOR +
                        r.getNoches() + SEPARADOR +
                        String.format("%.2f", r.getPrecioTotal()) + SEPARADOR +
                        escaparCSV(r.getEstado()));
                writer.newLine(); // salto de línea para cada reserva
            }

            // Mensaje de éxito
            System.out.println("✅ Exportación CSV de reservas completada: " + rutaCompleta);
            return true;

        } catch (IOException ex) {
            // Mensaje de error si algo falla al escribir
            System.out.println("❌ ERROR al escribir CSV: " + ex.getMessage());
            return false;
        }
    }

    // Método para escapar caracteres que podrían romper el CSV (comillas, saltos de línea, separadores)
    private static String escaparCSV(String texto) {
        if (texto == null) return "";
        if (texto.contains(SEPARADOR) || texto.contains("\"") || texto.contains("\n")) {
            return "\"" + texto.replace("\"", "\"\"") + "\""; // pongo comillas y doblo las comillas internas
        }
        return texto;
    }

    // MAIN de prueba, sirve para probar la exportación directamente
    public static void main(String[] args) {
        ArrayList<Reserva> reservas = new ArrayList<>();

        // Creo algunos clientes de prueba
        Cliente c1 = new Cliente(1, "Juan García", "juan@email.com", "666111222");
        Cliente c2 = new Cliente(2, "María López", "maria@email.com", "666333444");

        // Creo habitaciones de prueba
        Habitacion h1 = new Habitacion(101, "Doble", 90.0, false);
        Habitacion h2 = new Habitacion(205, "Suite", 200.0, true);

        // Creo reservas de ejemplo usando clientes y habitaciones
        reservas.add(new Reserva(1, c1, h1, java.time.LocalDate.parse("2025-10-20"),
                java.time.LocalDate.parse("2025-10-23"), 3, 270.0, "Confirmada"));
        reservas.add(new Reserva(2, c2, h2, java.time.LocalDate.parse("2025-10-21"),
                java.time.LocalDate.parse("2025-10-25"), 4, 800.0, "Confirmada"));

        // Llamo al método exportar para generar el CSV
        exportar(reservas, "reservas_hotel");
    }
}
