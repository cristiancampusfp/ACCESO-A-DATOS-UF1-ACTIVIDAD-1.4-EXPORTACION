import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;

public class ExportadorCSV {

    private static final String SEPARADOR = ";"; // Separador usado en el CSV (en este caso, punto y coma)
    private static final String DIRECTORIO = "exportaciones"; // Carpeta donde se guardarán los archivos CSV

    public static boolean exportar(ArrayList<Libro> libros, String nombreArchivo) {
        // Validación inicial: compruebo que la lista no esté vacía
        if (libros == null || libros.isEmpty()) {
            System.out.println("❌ ERROR: No hay libros para exportar.");
            return false;
        }

        // Validación del nombre del archivo
        if (nombreArchivo == null || nombreArchivo.trim().isEmpty()) {
            System.out.println("❌ ERROR: El nombre del archivo no puede estar vacío.");
            return false;
        }

        // Creo la carpeta de exportaciones si no existe
        File dir = new File(DIRECTORIO);
        if (!dir.exists()) dir.mkdir();

        // Construyo la ruta completa del archivo CSV
        String rutaCompleta = DIRECTORIO + File.separator + nombreArchivo + ".csv";

        // Agrupo los libros por categoría usando un HashMap
        HashMap<String, ArrayList<Libro>> categorias = new HashMap<>();
        for (Libro l : libros) {
            categorias.computeIfAbsent(l.getCategoria(), k -> new ArrayList<>()).add(l);
        }

        // Escribo el archivo CSV con try-with-resources
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(rutaCompleta))) {
            // Título general del catálogo
            writer.write("# BIBLIOTECA MUNICIPAL - CATÁLOGO DE LIBROS");
            writer.newLine();
            writer.newLine();

            // Recorro cada categoría y escribo su contenido
            for (String categoria : categorias.keySet()) {
                ArrayList<Libro> listaCat = categorias.get(categoria);

                // Encabezado de la categoría
                writer.write("# CATEGORÍA: " + categoria);
                writer.newLine();
                // Cabecera del CSV
                writer.write("ISBN" + SEPARADOR + "Título" + SEPARADOR + "Autor" + SEPARADOR +
                        "Año" + SEPARADOR + "Páginas" + SEPARADOR + "Disponible" + SEPARADOR + "Préstamos");
                writer.newLine();

                // Variables para subtotal de libros y préstamos por categoría
                int subtotalLibros = 0;
                int subtotalPrestamos = 0;

                // Escribo cada libro de la categoría
                for (Libro l : listaCat) {
                    writer.write(escaparCSV(l.getIsbn()) + SEPARADOR +
                            escaparCSV(l.getTitulo()) + SEPARADOR +
                            escaparCSV(l.getAutor()) + SEPARADOR +
                            l.getAñoPublicacion() + SEPARADOR +
                            l.getNumPaginas() + SEPARADOR +
                            l.isDisponible() + SEPARADOR +
                            l.getPrestamos());
                    writer.newLine();

                    // Actualizo los subtotales
                    subtotalLibros++;
                    subtotalPrestamos += l.getPrestamos();
                }

                // Escribo subtotal al final de la categoría
                writer.write("# Subtotal " + categoria + ": " + subtotalLibros + " libros, " + subtotalPrestamos + " préstamos");
                writer.newLine();
                writer.newLine();
            }

            // Mensaje de confirmación al finalizar
            System.out.println("✅ Exportación CSV completada: " + rutaCompleta);
            return true;

        } catch (IOException ex) {
            // Mensaje en caso de error al escribir el archivo
            System.out.println("❌ ERROR al escribir CSV: " + ex.getMessage());
            return false;
        }
    }

    // Método para escapar texto que contenga caracteres especiales o el separador
    private static String escaparCSV(String texto) {
        if (texto == null) return "";
        if (texto.contains(SEPARADOR) || texto.contains("\"") || texto.contains("\n")) {
            return "\"" + texto.replace("\"", "\"\"") + "\""; // Si hay comillas, las duplico
        }
        return texto;
    }

    public static void main(String[] args) {
        // Creo una lista de libros de ejemplo para probar la exportación
        ArrayList<Libro> biblioteca = new ArrayList<>();
        biblioteca.add(new Libro("978-84-123", "El Quijote", "Miguel de Cervantes", "Ficción", 1605, 863, true, 150));
        biblioteca.add(new Libro("978-84-456", "Cien años de soledad", "Gabriel García Márquez", "Ficción", 1967, 471, false, 98));
        biblioteca.add(new Libro("978-84-789", "Breve historia del tiempo", "Stephen Hawking", "Ciencia", 1988, 256, true, 120));
        biblioteca.add(new Libro("978-84-321", "El origen de las especies", "Charles Darwin", "Ciencia", 1859, 502, true, 75));
        biblioteca.add(new Libro("978-84-654", "La Iliada", "Homero", "Clásicos", -750, 600, false, 45));

        // Llamo al método exportar para crear el CSV con los datos de la biblioteca
        exportar(biblioteca, "biblioteca");
    }
}
