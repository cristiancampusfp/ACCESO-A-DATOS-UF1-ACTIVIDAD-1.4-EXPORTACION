import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class ExportadorXML {

    private static final String DIRECTORIO = "exportaciones"; // Carpeta donde se guardará el XML
    private static final String INDENT = "  "; // Indentación de 2 espacios para que el XML quede legible

    public static boolean exportar(ArrayList<Libro> libros, String nombreArchivo) {
        // Validación inicial: compruebo que la lista no esté vacía
        if (libros == null || libros.isEmpty()) {
            System.out.println("❌ ERROR: No hay libros para exportar.");
            return false;
        }

        // Validación del nombre del archivo
        if (nombreArchivo == null || nombreArchivo.trim().isEmpty()) {
            System.out.println("❌ ERROR: El nombre del archivo no puede estar vacío.");
            return false;
        }

        // Creo la carpeta de exportaciones si no existe
        File dir = new File(DIRECTORIO);
        if (!dir.exists()) dir.mkdir();

        // Ruta completa del archivo XML
        String rutaCompleta = DIRECTORIO + File.separator + nombreArchivo + ".xml";

        // Agrupo los libros por categoría usando HashMap
        HashMap<String, ArrayList<Libro>> categorias = new HashMap<>();
        for (Libro l : libros) {
            categorias.computeIfAbsent(l.getCategoria(), k -> new ArrayList<>()).add(l);
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(rutaCompleta))) {
            // Declaración XML inicial
            writer.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
            writer.newLine();
            writer.write("<biblioteca>");
            writer.newLine();

            // Información general de la biblioteca
            writer.write(INDENT + "<informacion>");
            writer.newLine();
            writer.write(INDENT + INDENT + "<nombre>Biblioteca Municipal</nombre>");
            writer.newLine();
            writer.write(INDENT + INDENT + "<fecha>");
            writer.write(LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
            writer.write("</fecha>");
            writer.newLine();
            writer.write(INDENT + INDENT + "<totalLibros>" + libros.size() + "</totalLibros>");
            writer.newLine();
            writer.write(INDENT + "</informacion>");
            writer.newLine();
            writer.newLine();

            // Inicio de las categorías
            writer.write(INDENT + "<categorias>");
            writer.newLine();

            int totalLibrosDisponibles = 0;
            int totalLibrosPrestados = 0;

            // Recorro cada categoría
            for (String categoria : categorias.keySet()) {
                ArrayList<Libro> listaCat = categorias.get(categoria);
                int totalPrestamosCat = 0;
                int librosDisponiblesCat = 0;

                // Calculo estadísticas de cada libro
                for (Libro l : listaCat) {
                    if (l.isDisponible()) librosDisponiblesCat++;
                    else totalLibrosPrestados++;
                    totalPrestamosCat += l.getPrestamos();
                }

                totalLibrosDisponibles += librosDisponiblesCat;

                // Inicio del nodo de categoría con atributos
                writer.write(INDENT + INDENT + "<categoria nombre=\"" + escaparXML(categoria) +
                        "\" totalLibros=\"" + listaCat.size() + "\">");
                writer.newLine();

                // Lista de libros dentro de la categoría
                for (Libro l : listaCat) {
                    writer.write(INDENT + INDENT + INDENT + "<libro isbn=\"" + escaparXML(l.getIsbn()) +
                            "\" disponible=\"" + l.isDisponible() + "\">");
                    writer.newLine();
                    writer.write(INDENT + INDENT + INDENT + INDENT + "<titulo>" + escaparXML(l.getTitulo()) + "</titulo>");
                    writer.newLine();
                    writer.write(INDENT + INDENT + INDENT + INDENT + "<autor>" + escaparXML(l.getAutor()) + "</autor>");
                    writer.newLine();
                    writer.write(INDENT + INDENT + INDENT + INDENT + "<año>" + l.getAñoPublicacion() + "</año>");
                    writer.newLine();
                    writer.write(INDENT + INDENT + INDENT + INDENT + "<paginas>" + l.getNumPaginas() + "</paginas>");
                    writer.newLine();
                    writer.write(INDENT + INDENT + INDENT + INDENT + "<prestamos>" + l.getPrestamos() + "</prestamos>");
                    writer.newLine();
                    writer.write(INDENT + INDENT + INDENT + "</libro>");
                    writer.newLine();
                }

                // Estadísticas de la categoría
                writer.write(INDENT + INDENT + INDENT + "<estadisticas>");
                writer.newLine();
                writer.write(INDENT + INDENT + INDENT + INDENT + "<totalPrestamos>" + totalPrestamosCat + "</totalPrestamos>");
                writer.newLine();
                writer.write(INDENT + INDENT + INDENT + INDENT + "<prestamosMedio>" + (totalPrestamosCat / (double) listaCat.size()) + "</prestamosMedio>");
                writer.newLine();
                writer.write(INDENT + INDENT + "</estadisticas>");
                writer.newLine();

                writer.write(INDENT + INDENT + "</categoria>");
                writer.newLine();
            }

            // Cierro las categorías
            writer.write(INDENT + "</categorias>");
            writer.newLine();

            // Resumen global de la biblioteca
            writer.write(INDENT + "<resumenGlobal>");
            writer.newLine();
            writer.write(INDENT + INDENT + "<totalCategorias>" + categorias.size() + "</totalCategorias>");
            writer.newLine();
            writer.write(INDENT + INDENT + "<totalLibros>" + libros.size() + "</totalLibros>");
            writer.newLine();
            writer.write(INDENT + INDENT + "<librosDisponibles>" + totalLibrosDisponibles + "</librosDisponibles>");
            writer.newLine();
            writer.write(INDENT + INDENT + "<librosPrestados>" + (libros.size() - totalLibrosDisponibles) + "</librosPrestados>");
            writer.newLine();
            writer.write(INDENT + "</resumenGlobal>");
            writer.newLine();

            // Cierro la raíz
            writer.write("</biblioteca>");
            writer.newLine();

            // Mensaje de confirmación
            System.out.println("✅ Exportación XML completada: " + rutaCompleta);
            return true;

        } catch (IOException ex) {
            // Mensaje de error si falla la escritura
            System.out.println("❌ ERROR al escribir XML: " + ex.getMessage());
            return false;
        }
    }

    // Método para escapar caracteres especiales en XML
    private static String escaparXML(String texto) {
        if (texto == null) return "";
        return texto.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&apos;");
    }

    // Método main de prueba
    public static void main(String[] args) {
        // Lista de libros de ejemplo
        ArrayList<Libro> biblioteca = new ArrayList<>();
        biblioteca.add(new Libro("978-84-123", "El Quijote", "Miguel de Cervantes", "Ficción", 1605, 863, true, 150));
        biblioteca.add(new Libro("978-84-456", "Cien años de soledad", "Gabriel García Márquez", "Ficción", 1967, 471, false, 98));
        biblioteca.add(new Libro("978-84-789", "Breve historia del tiempo", "Stephen Hawking", "Ciencia", 1988, 256, true, 120));
        biblioteca.add(new Libro("978-84-321", "El origen de las especies", "Charles Darwin", "Ciencia", 1859, 502, true, 75));
        biblioteca.add(new Libro("978-84-654", "La Iliada", "Homero", "Clásicos", -750, 600, false, 45));

        // Llamada al método exportar
        exportar(biblioteca, "biblioteca");
    }
}
