import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class ExportadorJSON {

    private static final String DIRECTORIO = "exportaciones"; // Carpeta donde se guardarán los archivos JSON
    private static final String INDENT = "  "; // Indentación de 2 espacios para que el JSON se vea ordenado

    public static boolean exportar(ArrayList<Libro> libros, String nombreArchivo) {
        // Validación: compruebo que la lista de libros no esté vacía
        if (libros == null || libros.isEmpty()) {
            System.out.println("❌ ERROR: No hay libros para exportar.");
            return false;
        }

        // Validación del nombre del archivo
        if (nombreArchivo == null || nombreArchivo.trim().isEmpty()) {
            System.out.println("❌ ERROR: El nombre del archivo no puede estar vacío.");
            return false;
        }

        // Creo la carpeta de exportaciones si no existe
        File dir = new File(DIRECTORIO);
        if (!dir.exists()) dir.mkdir();

        // Ruta completa del archivo JSON
        String rutaCompleta = DIRECTORIO + File.separator + nombreArchivo + ".json";

        // Agrupo los libros por categoría usando un HashMap
        HashMap<String, ArrayList<Libro>> categorias = new HashMap<>();
        for (Libro l : libros) {
            categorias.computeIfAbsent(l.getCategoria(), k -> new ArrayList<>()).add(l);
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(rutaCompleta))) {
            // Inicio del JSON principal
            writer.write("{");
            writer.newLine();
            writer.write(INDENT + "\"biblioteca\": {");
            writer.newLine();

            // Sección de información general
            writer.write(INDENT + INDENT + "\"informacion\": {");
            writer.newLine();
            writer.write(INDENT + INDENT + INDENT + "\"nombre\": \"Biblioteca Municipal\",");
            writer.newLine();
            writer.write(INDENT + INDENT + INDENT + "\"fecha\": \"" +
                    LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) + "\",");
            writer.newLine();
            writer.write(INDENT + INDENT + INDENT + "\"totalLibros\": " + libros.size());
            writer.newLine();
            writer.write(INDENT + INDENT + "},");
            writer.newLine();

            // Sección de categorías
            writer.write(INDENT + INDENT + "\"categorias\": {");
            writer.newLine();

            // Variables para resumen global
            int catCount = 0;
            int totalCategorias = categorias.size();
            int totalLibrosDisponibles = 0;
            int totalLibrosPrestados = 0;
            int totalPrestamosHistorico = 0;

            // Recorro cada categoría
            for (String categoria : categorias.keySet()) {
                ArrayList<Libro> listaCat = categorias.get(categoria);
                int totalPrestamosCat = 0;
                int librosDisponiblesCat = 0;

                // Recorro los libros de la categoría y calculo estadísticas locales
                for (Libro l : listaCat) {
                    if (l.isDisponible()) librosDisponiblesCat++;
                    else totalLibrosPrestados++;
                    totalPrestamosCat += l.getPrestamos();
                }

                totalLibrosDisponibles += librosDisponiblesCat;
                totalPrestamosHistorico += totalPrestamosCat;

                // Inicio del objeto de la categoría
                writer.write(INDENT + INDENT + INDENT + "\"" + escaparJSON(categoria) + "\": {");
                writer.newLine();
                writer.write(INDENT + INDENT + INDENT + INDENT + "\"totalLibros\": " + listaCat.size() + ",");
                writer.newLine();
                writer.write(INDENT + INDENT + INDENT + INDENT + "\"libros\": [");
                writer.newLine();

                // Escribo cada libro de la categoría
                int libCount = 0;
                for (Libro l : listaCat) {
                    writer.write(INDENT + INDENT + INDENT + INDENT + INDENT + "{");
                    writer.newLine();
                    writer.write(INDENT + INDENT + INDENT + INDENT + INDENT + INDENT + "\"isbn\": \"" + escaparJSON(l.getIsbn()) + "\",");
                    writer.newLine();
                    writer.write(INDENT + INDENT + INDENT + INDENT + INDENT + INDENT + "\"titulo\": \"" + escaparJSON(l.getTitulo()) + "\",");
                    writer.newLine();
                    writer.write(INDENT + INDENT + INDENT + INDENT + INDENT + INDENT + "\"autor\": \"" + escaparJSON(l.getAutor()) + "\",");
                    writer.newLine();
                    writer.write(INDENT + INDENT + INDENT + INDENT + INDENT + INDENT + "\"año\": " + l.getAñoPublicacion() + ",");
                    writer.newLine();
                    writer.write(INDENT + INDENT + INDENT + INDENT + INDENT + INDENT + "\"paginas\": " + l.getNumPaginas() + ",");
                    writer.newLine();
                    writer.write(INDENT + INDENT + INDENT + INDENT + INDENT + INDENT + "\"disponible\": " + l.isDisponible() + ",");
                    writer.newLine();
                    writer.write(INDENT + INDENT + INDENT + INDENT + INDENT + INDENT + "\"prestamos\": " + l.getPrestamos());
                    writer.newLine();
                    writer.write(INDENT + INDENT + INDENT + INDENT + INDENT + "}");
                    libCount++;
                    if (libCount < listaCat.size()) writer.write(","); // Coma si no es el último libro
                    writer.newLine();
                }

                // Cierro el array de libros
                writer.write(INDENT + INDENT + INDENT + INDENT + "],");
                writer.newLine();

                // Estadísticas de la categoría
                writer.write(INDENT + INDENT + INDENT + INDENT + "\"estadisticas\": {");
                writer.newLine();
                writer.write(INDENT + INDENT + INDENT + INDENT + INDENT + "\"totalPrestamos\": " + totalPrestamosCat + ",");
                writer.newLine();
                writer.write(INDENT + INDENT + INDENT + INDENT + INDENT + "\"prestamosMedio\": " + (totalPrestamosCat / (double) listaCat.size()) + ",");
                writer.newLine();

                // Determino el libro más prestado
                Libro libroMasPrestado = listaCat.get(0);
                for (Libro l : listaCat) {
                    if (l.getPrestamos() > libroMasPrestado.getPrestamos()) libroMasPrestado = l;
                }
                writer.write(INDENT + INDENT + INDENT + INDENT + INDENT + "\"libroMasPrestado\": \"" + escaparJSON(libroMasPrestado.getTitulo()) + "\"");
                writer.newLine();

                writer.write(INDENT + INDENT + INDENT + "}"); // Cierro estadisticas
                writer.newLine();
                writer.write(INDENT + INDENT + INDENT + "}"); // Cierro categoría
                catCount++;
                if (catCount < totalCategorias) writer.write(","); // Coma si no es la última categoría
                writer.newLine();
            }

            writer.write(INDENT + INDENT + "},"); // Cierro todas las categorías
            writer.newLine();

            // Resumen global de la biblioteca
            writer.write(INDENT + INDENT + "\"resumenGlobal\": {");
            writer.newLine();
            writer.write(INDENT + INDENT + INDENT + "\"totalCategorias\": " + totalCategorias + ",");
            writer.newLine();
            writer.write(INDENT + INDENT + INDENT + "\"totalLibros\": " + libros.size() + ",");
            writer.newLine();
            writer.write(INDENT + INDENT + INDENT + "\"librosDisponibles\": " + totalLibrosDisponibles + ",");
            writer.newLine();
            writer.write(INDENT + INDENT + INDENT + "\"librosPrestados\": " + totalLibrosPrestados + ",");
            writer.newLine();
            writer.write(INDENT + INDENT + INDENT + "\"totalPrestamosHistorico\": " + totalPrestamosHistorico);
            writer.newLine();
            writer.write(INDENT + INDENT + "}"); // Cierro resumen global
            writer.newLine();

            // Cierro JSON principal
            writer.write(INDENT + "}"); // Cierro "biblioteca"
            writer.newLine();
            writer.write("}");
            writer.newLine();

            // Mensaje de confirmación
            System.out.println("✅ Exportación JSON completada: " + rutaCompleta);
            return true;

        } catch (IOException ex) {
            // Mensaje de error si falla la escritura
            System.out.println("❌ ERROR al escribir JSON: " + ex.getMessage());
            return false;
        }
    }

    // Método para escapar caracteres especiales del JSON
    private static String escaparJSON(String texto) {
        if (texto == null) return "";
        return texto.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }

    public static void main(String[] args) {
        // Lista de libros de ejemplo para probar la exportación
        ArrayList<Libro> biblioteca = new ArrayList<>();
        biblioteca.add(new Libro("978-84-123", "El Quijote", "Miguel de Cervantes", "Ficción", 1605, 863, true, 150));
        biblioteca.add(new Libro("978-84-456", "Cien años de soledad", "Gabriel García Márquez", "Ficción", 1967, 471, false, 98));
        biblioteca.add(new Libro("978-84-789", "Breve historia del tiempo", "Stephen Hawking", "Ciencia", 1988, 256, true, 120));
        biblioteca.add(new Libro("978-84-321", "El origen de las especies", "Charles Darwin", "Ciencia", 1859, 502, true, 75));
        biblioteca.add(new Libro("978-84-654", "La Iliada", "Homero", "Clásicos", -750, 600, false, 45));

        // Llamada al método exportar para crear el JSON
        exportar(biblioteca, "biblioteca");
    }
}
