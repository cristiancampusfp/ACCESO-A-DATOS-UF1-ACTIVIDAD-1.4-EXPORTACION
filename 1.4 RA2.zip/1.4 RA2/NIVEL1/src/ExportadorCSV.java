import java.io.*;
import java.util.ArrayList;

public class ExportadorCSV {

    private static final String SEPARADOR = ","; // Defino el separador del CSV, en este caso una coma
    private static final String DIRECTORIO = "exportaciones"; // Nombre de la carpeta donde se van a guardar los archivos exportados

    public static boolean exportar(ArrayList<Estudiante> estudiantes , String nombreArchivo) {

        // Primero se comprueba que la lista de estudiantes no esté vacía o nula
        if (estudiantes == null || estudiantes.isEmpty()) {
            System.out.println(" No hay estudiantes para exportar");
            return false;
        }

        // También se valida que el nombre del archivo no esté vacío
        if (nombreArchivo == null || nombreArchivo.trim().isEmpty()) {
            System.out.println(" El nombre del archivo no puede estar vacio");
            return false;
        }

        // Se crea el directorio "exportaciones" si no existe
        File dir = new File(DIRECTORIO);
        if (!dir.exists()) dir.mkdirs();

        // Construyo la ruta completa donde se guardará el archivo CSV
        String rutaCompleta = DIRECTORIO + File.separator + nombreArchivo + ".csv";

        // Uso try-with-resources para asegurarme que el writer se cierre automáticamente
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(rutaCompleta))) {

            // Escribo la cabecera del CSV
            writer.write("ID" + SEPARADOR + "Nombre" + SEPARADOR + "Apellidos"
                    + SEPARADOR + "Edad" + SEPARADOR + "Nota");
            writer.newLine();

            double sumaNotas = 0; // Variable para calcular la nota media más adelante

            // Recorro todos los estudiantes para escribir sus datos en el archivo
            for (Estudiante e : estudiantes) {
                writer.write(e.getId() + SEPARADOR +
                        escaparCSV(e.getNombre()) + SEPARADOR +
                        escaparCSV(e.getApellidos()) + SEPARADOR +
                        e.getEdad() + SEPARADOR +
                        String.format("%.2f", e.getNota())); // Formateo las notas con dos decimales
                writer.newLine();
                sumaNotas += e.getNota(); // Acumulo las notas para luego calcular la media
            }

            // Calculo la nota media de todos los estudiantes
            double notaMedia = sumaNotas / estudiantes.size();
            // Escribo una línea especial con la nota media
            writer.write("#Nota media" + SEPARADOR + String.format("%.2f", notaMedia));
            writer.newLine();

            // Mensaje de confirmación al finalizar la exportación
            System.out.println("Exportacion CSV completada " + rutaCompleta);
            return true;

        } catch (IOException ex){
            // En caso de error de escritura, muestro el mensaje
            System.out.println(" Error al escribir csv " + ex.getMessage());
            return false;
        }
    }

    // Este método se usa para evitar problemas con comas o saltos de línea dentro de los campos
    private static String escaparCSV(String texto) {
        if (texto == null) return "";
        if (texto.contains(SEPARADOR) || texto.contains("\"") || texto.contains("\n")) {
            return "\"" + texto.replace("\"", "\"\"") + "\""; // Reemplazo comillas dobles por dobles comillas dentro del texto
        }
        return texto;
    }

    public static void main(String[] args) {
        // Creo una lista de estudiantes de ejemplo para probar la exportación
        ArrayList<Estudiante> lista = new ArrayList<>();
        lista.add(new Estudiante(1, "Juan", "García López", 20, 8.5));
        lista.add(new Estudiante(2, "María", "Rodríguez", 19, 9.2));
        lista.add(new Estudiante(3, "Pedro", "Martínez", 21, 7.8));
        lista.add(new Estudiante(4, "Ana", "López", 20, 8.9));
        lista.add(new Estudiante(5, "Carlos", "Sánchez", 22, 6.5));

        // Llamo al método exportar para generar el archivo CSV con los datos de los estudiantes
        exportar(lista, "estudiantes");
    }
}
