import java.io.*;
import java.util.ArrayList;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class ExportadorXML {

    private static final String DIRECTORIO = "exportaciones"; // Carpeta donde se van a guardar los archivos XML
    private static final String INDENT = "  "; // Uso dos espacios para que el XML quede bien indentado y legible

    public static boolean exportar(ArrayList<Estudiante> estudiantes, String nombreArchivo) {

        // Primero reviso que la lista de estudiantes no esté vacía o nula
        if (estudiantes == null || estudiantes.isEmpty()) {
            System.out.println("❌ ERROR: No hay estudiantes para exportar.");
            return false;
        }

        // También compruebo que el nombre del archivo no esté vacío
        if (nombreArchivo == null || nombreArchivo.trim().isEmpty()) {
            System.out.println("❌ ERROR: El nombre del archivo no puede estar vacío.");
            return false;
        }

        // Creo la carpeta de exportaciones si no existe
        File dir = new File(DIRECTORIO);
        if (!dir.exists()) dir.mkdir();

        // Genero la ruta completa donde se guardará el archivo XML
        String rutaCompleta = DIRECTORIO + File.separator + nombreArchivo + ".xml";

        // Uso try-with-resources para manejar el archivo de forma segura (se cierra solo)
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(rutaCompleta))) {

            // Esta línea define la versión del XML y el tipo de codificación
            writer.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
            writer.newLine();

            // Agrego un comentario al principio para identificar el contenido
            writer.write("<!-- Catálogo de estudiantes generado automáticamente -->");
            writer.newLine();

            // Nodo raíz del XML
            writer.write("<clase>");
            writer.newLine();

            // Llamo a los métodos auxiliares para escribir cada parte del XML
            escribirMetadata(writer, estudiantes);   // Información general
            escribirEstudiantes(writer, estudiantes); // Lista de los estudiantes
            escribirResumen(writer, estudiantes);    // Estadísticas

            // Cierro la etiqueta raíz
            writer.write("</clase>");
            writer.newLine();

            // Mensaje en consola para confirmar la exportación exitosa
            System.out.println("✅ Exportación XML completada: " + rutaCompleta);
            return true;

        } catch (IOException e) {
            // Si algo falla al escribir el archivo, muestro un mensaje de error
            System.out.println("❌ ERROR al escribir XML: " + e.getMessage());
            return false;
        }
    }

    // Método para escribir los metadatos del archivo (fecha y cantidad de estudiantes)
    private static void escribirMetadata(BufferedWriter writer, ArrayList<Estudiante> estudiantes) throws IOException {
        writer.write(INDENT + "<metadata>");
        writer.newLine();

        // Agrego la fecha actual con formato día/mes/año
        writer.write(INDENT + INDENT + "<fecha>" +
                LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) +
                "</fecha>");
        writer.newLine();

        // Indico el número total de estudiantes en el archivo
        writer.write(INDENT + INDENT + "<totalEstudiantes>" + estudiantes.size() + "</totalEstudiantes>");
        writer.newLine();

        writer.write(INDENT + "</metadata>");
        writer.newLine();
    }

    // Método que escribe cada estudiante dentro de la etiqueta <estudiantes>
    private static void escribirEstudiantes(BufferedWriter writer, ArrayList<Estudiante> estudiantes) throws IOException {
        writer.write(INDENT + "<estudiantes>");
        writer.newLine();

        // Recorro la lista de estudiantes y creo un bloque XML para cada uno
        for (Estudiante e : estudiantes) {
            writer.write(INDENT + INDENT + "<estudiante id=\"" + e.getId() + "\">");
            writer.newLine();

            // Cada dato del estudiante va dentro de su propia etiqueta
            writer.write(INDENT + INDENT + INDENT + "<nombre>" + escaparXML(e.getNombre()) + "</nombre>");
            writer.newLine();
            writer.write(INDENT + INDENT + INDENT + "<apellidos>" + escaparXML(e.getApellidos()) + "</apellidos>");
            writer.newLine();
            writer.write(INDENT + INDENT + INDENT + "<edad>" + e.getEdad() + "</edad>");
            writer.newLine();
            writer.write(INDENT + INDENT + INDENT + "<nota>" + String.format("%.2f", e.getNota()) + "</nota>");
            writer.newLine();

            // Cierro la etiqueta de estudiante
            writer.write(INDENT + INDENT + "</estudiante>");
            writer.newLine();
        }

        // Cierro la lista de estudiantes
        writer.write(INDENT + "</estudiantes>");
        writer.newLine();
    }

    // Método para generar un resumen con estadísticas de las notas
    private static void escribirResumen(BufferedWriter writer, ArrayList<Estudiante> estudiantes) throws IOException {
        double suma = 0;
        double notaMax = Double.MIN_VALUE;
        double notaMin = Double.MAX_VALUE;

        // Calculo la suma total, nota máxima y mínima
        for (Estudiante e : estudiantes) {
            suma += e.getNota();
            if (e.getNota() > notaMax) notaMax = e.getNota();
            if (e.getNota() < notaMin) notaMin = e.getNota();
        }

        // Calculo la nota media
        double notaMedia = suma / estudiantes.size();

        // Escribo el bloque de resumen con los resultados
        writer.write(INDENT + "<resumen>");
        writer.newLine();
        writer.write(INDENT + INDENT + "<notaMedia>" + String.format("%.2f", notaMedia) + "</notaMedia>");
        writer.newLine();
        writer.write(INDENT + INDENT + "<notaMaxima>" + String.format("%.2f", notaMax) + "</notaMaxima>");
        writer.newLine();
        writer.write(INDENT + INDENT + "<notaMinima>" + String.format("%.2f", notaMin) + "</notaMinima>");
        writer.newLine();
        writer.write(INDENT + "</resumen>");
        writer.newLine();
    }

    // Este método reemplaza los caracteres especiales que podrían romper el formato XML
    private static String escaparXML(String texto) {
        if (texto == null || texto.isEmpty()) return "";
        return texto.replace("&", "&amp;")   // Reemplazo & por &amp;
                .replace("<", "&lt;")        // Reemplazo < por &lt;
                .replace(">", "&gt;")        // Reemplazo > por &gt;
                .replace("\"", "&quot;")     // Reemplazo comillas dobles
                .replace("'", "&apos;");     // Reemplazo comillas simples
    }

    public static void main(String[] args) {
        // Creo una lista de estudiantes de ejemplo para probar la exportación
        ArrayList<Estudiante> lista = new ArrayList<>();
        lista.add(new Estudiante(1, "Juan", "García López", 20, 8.5));
        lista.add(new Estudiante(2, "María", "Rodríguez", 19, 9.2));
        lista.add(new Estudiante(3, "Pedro", "Martínez", 21, 7.8));
        lista.add(new Estudiante(4, "Ana", "López", 20, 8.9));
        lista.add(new Estudiante(5, "Carlos", "Sánchez", 22, 6.5));

        // Llamo al método exportar para crear el archivo XML con los datos
        exportar(lista, "estudiantes");
    }
}
