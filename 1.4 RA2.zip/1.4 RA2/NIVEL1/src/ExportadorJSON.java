import java.io.*;
import java.util.ArrayList;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class ExportadorJSON {

    private static final String DIRECTORIO = "exportaciones"; // Carpeta donde se van a guardar los archivos JSON
    private static final String INDENT = "  "; // Defino la indentación con 2 espacios para que el JSON se vea más ordenado

    public static boolean exportar(ArrayList<Estudiante> estudiantes, String nombreArchivo) {

        // Primero verifico que la lista de estudiantes no esté vacía
        if (estudiantes == null || estudiantes.isEmpty()) {
            System.out.println("❌ ERROR: No hay estudiantes para exportar.");
            return false;
        }

        // También valido que el nombre del archivo no esté vacío o en blanco
        if (nombreArchivo == null || nombreArchivo.trim().isEmpty()) {
            System.out.println("❌ ERROR: El nombre del archivo no puede estar vacío.");
            return false;
        }

        // Creo la carpeta "exportaciones" si no existe
        File dir = new File(DIRECTORIO);
        if (!dir.exists()) dir.mkdir();

        // Armo la ruta completa donde se guardará el archivo JSON
        String rutaCompleta = DIRECTORIO + File.separator + nombreArchivo + ".json";

        // Uso try-with-resources para abrir el archivo y asegurar que se cierre al terminar
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(rutaCompleta))) {

            // Inicio del objeto JSON principal
            writer.write("{");
            writer.newLine();
            writer.write(INDENT + "\"clase\": {");
            writer.newLine();

            // Sección de metadatos (fecha y cantidad total de estudiantes)
            writer.write(INDENT + INDENT + "\"metadata\": {");
            writer.newLine();
            writer.write(INDENT + INDENT + INDENT + "\"fecha\": \"" +
                    LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) + "\"," );
            writer.newLine();
            writer.write(INDENT + INDENT + INDENT + "\"totalEstudiantes\": " + estudiantes.size());
            writer.newLine();
            writer.write(INDENT + INDENT + "},");
            writer.newLine();

            // Sección donde se listan todos los estudiantes
            writer.write(INDENT + INDENT + "\"estudiantes\": [");
            writer.newLine();

            int total = estudiantes.size();
            for (int i = 0; i < total; i++) {
                Estudiante e = estudiantes.get(i);

                // Abro el objeto de cada estudiante
                writer.write(INDENT + INDENT + INDENT + "{");
                writer.newLine();

                // Escribo todos los campos del estudiante en formato JSON
                writer.write(INDENT + INDENT + INDENT + INDENT + "\"id\": " + e.getId() + ",");
                writer.newLine();
                writer.write(INDENT + INDENT + INDENT + INDENT + "\"nombre\": \"" + escaparJSON(e.getNombre()) + "\"," );
                writer.newLine();
                writer.write(INDENT + INDENT + INDENT + INDENT + "\"apellidos\": \"" + escaparJSON(e.getApellidos()) + "\"," );
                writer.newLine();
                writer.write(INDENT + INDENT + INDENT + INDENT + "\"edad\": " + e.getEdad() + ",");
                writer.newLine();
                writer.write(INDENT + INDENT + INDENT + INDENT + "\"nota\": " + String.format("%.2f", e.getNota()));
                writer.newLine();

                // Cierro el objeto del estudiante
                writer.write(INDENT + INDENT + INDENT + "}");
                if (i < total - 1) writer.write(","); // Pongo coma si no es el último estudiante
                writer.newLine();
            }

            // Cierro el array de estudiantes
            writer.write(INDENT + INDENT + "],");
            writer.newLine();

            // A partir de aquí calculo las estadísticas generales
            double suma = 0;
            double notaMax = Double.MIN_VALUE;
            double notaMin = Double.MAX_VALUE;
            int aprobados = 0;
            int suspensos = 0;

            // Recorro la lista para calcular nota media, máxima, mínima y contar aprobados/suspensos
            for (Estudiante e : estudiantes) {
                double nota = e.getNota();
                suma += nota;
                if (nota > notaMax) notaMax = nota;
                if (nota < notaMin) notaMin = nota;
                if (nota >= 5.0) aprobados++;
                else suspensos++;
            }

            double notaMedia = suma / estudiantes.size();

            // Escribo las estadísticas dentro del JSON
            writer.write(INDENT + INDENT + "\"estadisticas\": {");
            writer.newLine();
            writer.write(INDENT + INDENT + INDENT + "\"notaMedia\": " + String.format("%.2f", notaMedia) + ",");
            writer.newLine();
            writer.write(INDENT + INDENT + INDENT + "\"notaMaxima\": " + String.format("%.2f", notaMax) + ",");
            writer.newLine();
            writer.write(INDENT + INDENT + INDENT + "\"notaMinima\": " + String.format("%.2f", notaMin) + ",");
            writer.newLine();
            writer.write(INDENT + INDENT + INDENT + "\"aprobados\": " + aprobados + ",");
            writer.newLine();
            writer.write(INDENT + INDENT + INDENT + "\"suspensos\": " + suspensos);
            writer.newLine();
            writer.write(INDENT + INDENT + "}"); // Cierro el bloque de estadísticas
            writer.newLine();

            // Cierro todo el JSON
            writer.write(INDENT + "}"); // Cierro el objeto "clase"
            writer.newLine();
            writer.write("}"); // Cierro el JSON principal
            writer.newLine();

            // Mensaje para confirmar que la exportación fue exitosa
            System.out.println("✅ Exportación JSON completada: " + rutaCompleta);
            return true;

        } catch (IOException e) {
            // En caso de error, lo informo en consola
            System.out.println("❌ ERROR al escribir JSON: " + e.getMessage());
            return false;
        }
    }

    // Este método sirve para "escapar" caracteres especiales que pueden romper el formato JSON
    private static String escaparJSON(String texto) {
        if (texto == null || texto.isEmpty()) return "";
        return texto.replace("\\", "\\\\") // Escapo las barras invertidas
                .replace("\"", "\\\"")    // Escapo las comillas dobles
                .replace("\n", "\\n")     // Escapo los saltos de línea
                .replace("\r", "\\r")     // Escapo retornos de carro
                .replace("\t", "\\t");    // Escapo tabulaciones
    }

    public static void main(String[] args) {
        // Creo una lista de estudiantes para probar la exportación
        ArrayList<Estudiante> lista = new ArrayList<>();
        lista.add(new Estudiante(1, "Juan", "García López", 20, 8.5));
        lista.add(new Estudiante(2, "María", "Rodríguez", 19, 9.2));
        lista.add(new Estudiante(3, "Pedro", "Martínez", 21, 7.8));
        lista.add(new Estudiante(4, "Ana", "López", 20, 8.9));
        lista.add(new Estudiante(5, "Carlos", "Sánchez", 22, 6.5));

        // Llamo al método exportar para generar el archivo JSON con los datos
        exportar(lista, "estudiantes");
    }
}
