// ─────────────── CLASE CLIENTE ───────────────
// Esta clase guarda toda la información de un cliente del hotel.
// Cada cliente tiene un id único, nombre, email y teléfono.
public class Cliente {
    private int id;
    private String nombre;
    private String email;
    private String telefono;

    // Constructor de la clase
    public Cliente(int id, String nombre, String email, String telefono) {
        this.id = id;
        this.nombre = nombre;
        this.email = email;
        this.telefono = telefono;
    }

    // Getters para poder acceder a los datos desde otras clases
    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public String getEmail() { return email; }
    public String getTelefono() { return telefono; }
}
