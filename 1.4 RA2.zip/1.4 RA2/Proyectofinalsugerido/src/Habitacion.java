// ─────────────── CLASE HABITACIÓN ───────────────
// Esta clase representa una habitación del hotel.
// Contiene el número de habitación, tipo, precio por noche y si está disponible.
public class Habitacion {
    private int numero;
    private String tipo;
    private double precioPorNoche;
    private boolean disponible;

    // Constructor de la clase
    public Habitacion(int numero, String tipo, double precioPorNoche, boolean disponible) {
        this.numero = numero;
        this.tipo = tipo;
        this.precioPorNoche = precioPorNoche;
        this.disponible = disponible;
    }

    // Getters para acceder a los datos desde otras clases
    public int getNumero() { return numero; }
    public String getTipo() { return tipo; }
    public double getPrecioPorNoche() { return precioPorNoche; }
    public boolean isDisponible() { return disponible; }
}
