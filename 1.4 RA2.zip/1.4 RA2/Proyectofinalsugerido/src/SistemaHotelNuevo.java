import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Scanner;

// Clase principal del sistema de gestión de hotel
public class SistemaHotelNuevo {

    private static ArrayList<Cliente> clientes = new ArrayList<>();
    private static ArrayList<Habitacion> habitaciones = new ArrayList<>();
    private static ArrayList<Reserva> reservas = new ArrayList<>();
    private static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        // Menú principal
        int opcion;
        do {
            mostrarMenu();
            opcion = leerEntero("Elige una opción: ");
            switch (opcion) {
                case 1 -> agregarCliente();
                case 2 -> agregarHabitacion();
                case 3 -> agregarReserva();
                case 4 -> mostrarReservas();
                case 5 -> exportarReservas();
                case 0 -> System.out.println("Saliendo del sistema...");
                default -> System.out.println("❌ Opción no válida.");
            }
        } while (opcion != 0);
    }

    // ─────────── MENÚ ───────────
    private static void mostrarMenu() {
        System.out.println("\n==== Sistema Hotel Paradise ====");
        System.out.println("1. Agregar cliente");
        System.out.println("2. Agregar habitación");
        System.out.println("3. Agregar reserva");
        System.out.println("4. Mostrar reservas");
        System.out.println("5. Exportar reservas");
        System.out.println("0. Salir");
    }

    // ─────────── AGREGAR CLIENTE ───────────
    private static void agregarCliente() {
        System.out.println("\n--- Agregar Cliente ---");
        int id = leerEntero("ID Cliente: ");
        System.out.print("Nombre: ");
        String nombre = sc.nextLine();
        System.out.print("Email: ");
        String email = sc.nextLine();
        System.out.print("Teléfono: ");
        String telefono = sc.nextLine();

        clientes.add(new Cliente(id, nombre, email, telefono));
        System.out.println("✅ Cliente agregado correctamente.");
    }

    // ─────────── AGREGAR HABITACIÓN ───────────
    private static void agregarHabitacion() {
        System.out.println("\n--- Agregar Habitación ---");
        int numero = leerEntero("Número de habitación: ");
        System.out.print("Tipo (Individual/Doble/Suite): ");
        String tipo = sc.nextLine();
        double precio = leerDouble("Precio por noche: ");
        boolean disponible = true; // al crear siempre disponible

        habitaciones.add(new Habitacion(numero, tipo, precio, disponible));
        System.out.println("✅ Habitación agregada correctamente.");
    }

    // ─────────── AGREGAR RESERVA ───────────
    private static void agregarReserva() {
        System.out.println("\n--- Agregar Reserva ---");

        // Seleccionar cliente
        Cliente cliente = null;
        if (clientes.isEmpty()) {
            System.out.println("❌ No hay clientes disponibles. Primero agrega un cliente.");
            return;
        }
        while (cliente == null) {
            System.out.println("Selecciona el ID del cliente:");
            for (Cliente c : clientes) System.out.println(c.getId() + " - " + c.getNombre());
            int idCliente = leerEntero("ID Cliente: ");
            for (Cliente c : clientes) {
                if (c.getId() == idCliente) cliente = c;
            }
            if (cliente == null) System.out.println("❌ Cliente no encontrado. Intenta de nuevo.");
        }

        // Seleccionar habitación
        Habitacion hab = null;
        if (habitaciones.isEmpty()) {
            System.out.println("❌ No hay habitaciones disponibles. Primero agrega una habitación.");
            return;
        }
        while (hab == null) {
            System.out.println("Selecciona el número de habitación:");
            for (Habitacion h : habitaciones) System.out.println(h.getNumero() + " - " + h.getTipo());
            int numHab = leerEntero("Número habitación: ");
            for (Habitacion h : habitaciones) {
                if (h.getNumero() == numHab) hab = h;
            }
            if (hab == null) System.out.println("❌ Habitación no encontrada. Intenta de nuevo.");
        }

        // Fechas con control de errores
        LocalDate entrada = null;
        while (entrada == null) {
            System.out.print("Fecha de entrada (YYYY-MM-DD): ");
            try {
                entrada = LocalDate.parse(sc.nextLine());
            } catch (DateTimeParseException e) {
                System.out.println("❌ Formato incorrecto. Intenta de nuevo.");
            }
        }

        LocalDate salida = null;
        while (salida == null) {
            System.out.print("Fecha de salida (YYYY-MM-DD): ");
            try {
                salida = LocalDate.parse(sc.nextLine());
                if (salida.isBefore(entrada)) {
                    System.out.println("❌ La fecha de salida no puede ser antes de la entrada.");
                    salida = null;
                }
            } catch (DateTimeParseException e) {
                System.out.println("❌ Formato incorrecto. Intenta de nuevo.");
            }
        }

        int noches = (int) (salida.toEpochDay() - entrada.toEpochDay());
        double total = noches * hab.getPrecioPorNoche();

        int idReserva = reservas.size() + 1;
        reservas.add(new Reserva(idReserva, cliente, hab, entrada, salida,  "Confirmada"));

        System.out.println("✅ Reserva agregada correctamente. Total: " + total + " €");
    }

    // ─────────── MOSTRAR RESERVAS ───────────
    private static void mostrarReservas() {
        System.out.println("\n--- Reservas ---");
        if (reservas.isEmpty()) {
            System.out.println("No hay reservas disponibles.");
            return;
        }
        for (Reserva r : reservas) {
            System.out.println("ID: " + r.getId() +
                    ", Cliente: " + r.getCliente().getNombre() +
                    ", Habitación: " + r.getHabitacion().getNumero() +
                    ", Entrada: " + r.getFechaEntrada() +
                    ", Salida: " + r.getFechaSalida() +
                    ", Noches: " + r.getNoches() +
                    ", Total: " + r.getPrecioTotal() +
                    ", Estado: " + r.getEstado());
        }
    }

    // ─────────── EXPORTAR RESERVAS ───────────
    private static void exportarReservas() {
        System.out.println("\n--- Exportar Reservas ---");
        System.out.print("Exportar CSV? (s/n): ");
        boolean csv = sc.nextLine().equalsIgnoreCase("s");
        System.out.print("Exportar XML? (s/n): ");
        boolean xml = sc.nextLine().equalsIgnoreCase("s");
        System.out.print("Exportar JSON? (s/n): ");
        boolean json = sc.nextLine().equalsIgnoreCase("s");

        if (!csv && !xml && !json) {
            System.out.println("❌ No seleccionaste ningún formato.");
            return;
        }

        // Exportar usando las clases ya creadas
        String timestamp = LocalDate.now().toString();
        if (csv) ExportadorCSV.exportar(reservas, "reservas_" + timestamp);
        if (xml) ExportadorXML.exportar(reservas, "reservas_" + timestamp);
        // Aquí podrías llamar ExportadorJSON.exportar(...) si tienes la clase JSON
    }

    // ─────────── MÉTODOS AUXILIARES ───────────
    private static int leerEntero(String mensaje) {
        int valor = -1;
        while (true) {
            System.out.print(mensaje);
            try {
                valor = Integer.parseInt(sc.nextLine());
                return valor;
            } catch (NumberFormatException e) {
                System.out.println("❌ Entrada inválida. Debe ser un número.");
            }
        }
    }

    private static double leerDouble(String mensaje) {
        double valor = -1;
        while (true) {
            System.out.print(mensaje);
            try {
                valor = Double.parseDouble(sc.nextLine());
                return valor;
            } catch (NumberFormatException e) {
                System.out.println("❌ Entrada inválida. Debe ser un número decimal.");
            }
        }
    }
}
