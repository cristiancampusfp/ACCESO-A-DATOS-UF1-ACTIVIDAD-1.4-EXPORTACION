import java.io.*;
import java.time.LocalDate;
import java.util.ArrayList;

public class ExportadorJSON {

    private static final String DIRECTORIO = "exportaciones";

    public static boolean exportar(ArrayList<Reserva> reservas, String nombreArchivo) {
        if (reservas == null || reservas.isEmpty()) {
            System.out.println("❌ ERROR: No hay reservas para exportar.");
            return false;
        }
        if (nombreArchivo == null || nombreArchivo.trim().isEmpty()) {
            System.out.println("❌ ERROR: El nombre del archivo no puede estar vacío.");
            return false;
        }

        File dir = new File(DIRECTORIO);
        if (!dir.exists()) dir.mkdir();
        String rutaCompleta = DIRECTORIO + File.separator + nombreArchivo + ".json";

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(rutaCompleta))) {
            String IND = "  "; // Indentación
            writer.write("{\n" + IND + "\"reservas\": [\n");
            for (int i = 0; i < reservas.size(); i++) {
                Reserva r = reservas.get(i);
                writer.write(IND + IND + "{\n");
                writer.write(IND + IND + IND + "\"id\": " + r.getId() + ",\n");
                writer.write(IND + IND + IND + "\"cliente\": \"" + escaparJSON(r.getCliente().getNombre()) + "\",\n");
                writer.write(IND + IND + IND + "\"habitacion\": \"" + escaparJSON(r.getHabitacion().getTipo()) + "\",\n");
                writer.write(IND + IND + IND + "\"fechaEntrada\": \"" + r.getFechaEntrada() + "\",\n");
                writer.write(IND + IND + IND + "\"fechaSalida\": \"" + r.getFechaSalida() + "\",\n");
                writer.write(IND + IND + IND + "\"precioTotal\": " + r.getPrecioTotal() + ",\n");
                writer.write(IND + IND + IND + "\"estado\": \"" + escaparJSON(r.getEstado()) + "\"\n");
                writer.write(IND + IND + "}" + (i < reservas.size() - 1 ? "," : "") + "\n");
            }
            writer.write(IND + "]\n}");
            System.out.println("✅ Exportación JSON completada: " + rutaCompleta);
            return true;

        } catch (IOException e) {
            System.out.println("❌ ERROR al escribir JSON: " + e.getMessage());
            return false;
        }
    }

    private static String escaparJSON(String texto) {
        if (texto == null) return "";
        return texto.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n");
    }
}
