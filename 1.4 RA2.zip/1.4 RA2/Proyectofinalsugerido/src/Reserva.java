import java.time.LocalDate;

// ─────────────── CLASE RESERVA ───────────────
// Guarda la información de una reserva específica.
// Cada reserva está asociada a un cliente y una habitación.
// También contiene las fechas de entrada y salida, estado y métodos para calcular precio y noches.
public class Reserva {
    private int id;
    private Cliente cliente;
    private Habitacion habitacion;
    private LocalDate fechaEntrada;
    private LocalDate fechaSalida;
    private String estado; // Ej: Confirmada, Cancelada, Completada

    // Constructor
    public Reserva(int id, Cliente cliente, Habitacion habitacion, LocalDate fechaEntrada, LocalDate fechaSalida, String estado) {
        this.id = id;
        this.cliente = cliente;
        this.habitacion = habitacion;
        this.fechaEntrada = fechaEntrada;
        this.fechaSalida = fechaSalida;
        this.estado = estado;
    }

    // Getters para acceder a los datos
    public int getId() { return id; }
    public Cliente getCliente() { return cliente; }
    public Habitacion getHabitacion() { return habitacion; }
    public LocalDate getFechaEntrada() { return fechaEntrada; }
    public LocalDate getFechaSalida() { return fechaSalida; }
    public String getEstado() { return estado; }

    // Calcula el número de noches de la reserva
    public int getNoches() {
        return (int) (fechaSalida.toEpochDay() - fechaEntrada.toEpochDay());
    }

    // Calcula el precio total de la reserva (noches * precio por noche)
    public double getPrecioTotal() {
        return getNoches() * habitacion.getPrecioPorNoche();
    }
}
