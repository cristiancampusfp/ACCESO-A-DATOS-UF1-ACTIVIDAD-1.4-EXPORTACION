import java.io.*;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class ExportadorCSV {

    private static final String SEPARADOR = ";"; // Separador de columnas
    private static final String DIRECTORIO = "exportaciones"; // Carpeta donde guardamos los CSV

    // Método principal para exportar reservas a CSV
    public static boolean exportar(ArrayList<Reserva> reservas, String nombreArchivo) {
        // Control de errores: lista vacía o nula
        if (reservas == null || reservas.isEmpty()) {
            System.out.println("❌ ERROR: No hay reservas para exportar.");
            return false;
        }
        // Control de errores: nombre de archivo vacío
        if (nombreArchivo == null || nombreArchivo.trim().isEmpty()) {
            System.out.println("❌ ERROR: El nombre del archivo no puede estar vacío.");
            return false;
        }

        // Crear carpeta si no existe
        File dir = new File(DIRECTORIO);
        if (!dir.exists()) dir.mkdir();

        String rutaCompleta = DIRECTORIO + File.separator + nombreArchivo + ".csv";
        DateTimeFormatter formatoFecha = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(rutaCompleta))) {
            // Encabezado CSV
            writer.write("ID" + SEPARADOR +
                    "ClienteNombre" + SEPARADOR +
                    "ClienteEmail" + SEPARADOR +
                    "ClienteTelefono" + SEPARADOR +
                    "HabitacionNum" + SEPARADOR +
                    "TipoHabitacion" + SEPARADOR +
                    "PrecioPorNoche" + SEPARADOR +
                    "Disponible" + SEPARADOR +
                    "FechaEntrada" + SEPARADOR +
                    "FechaSalida" + SEPARADOR +
                    "Noches" + SEPARADOR +
                    "PrecioTotal" + SEPARADOR +
                    "Estado");
            writer.newLine();

            // Recorremos todas las reservas y escribimos sus datos
            for (Reserva r : reservas) {
                writer.write(r.getId() + SEPARADOR +
                        escaparCSV(r.getCliente().getNombre()) + SEPARADOR +
                        escaparCSV(r.getCliente().getEmail()) + SEPARADOR +
                        escaparCSV(r.getCliente().getTelefono()) + SEPARADOR +
                        r.getHabitacion().getNumero() + SEPARADOR +
                        escaparCSV(r.getHabitacion().getTipo()) + SEPARADOR +
                        String.format("%.2f", r.getHabitacion().getPrecioPorNoche()) + SEPARADOR +
                        r.getHabitacion().isDisponible() + SEPARADOR +
                        r.getFechaEntrada().format(formatoFecha) + SEPARADOR +
                        r.getFechaSalida().format(formatoFecha) + SEPARADOR +
                        r.getNoches() + SEPARADOR +
                        String.format("%.2f", r.getPrecioTotal()) + SEPARADOR +
                        escaparCSV(r.getEstado()));
                writer.newLine();
            }

            System.out.println("✅ Exportación CSV de reservas completada: " + rutaCompleta);
            return true;

        } catch (IOException ex) {
            System.out.println("❌ ERROR al escribir CSV: " + ex.getMessage());
            return false;
        }
    }

    // Método para escapar caracteres especiales en CSV
    private static String escaparCSV(String texto) {
        if (texto == null) return "";
        if (texto.contains(SEPARADOR) || texto.contains("\"") || texto.contains("\n")) {
            return "\"" + texto.replace("\"", "\"\"") + "\"";
        }
        return texto;
    }
}
