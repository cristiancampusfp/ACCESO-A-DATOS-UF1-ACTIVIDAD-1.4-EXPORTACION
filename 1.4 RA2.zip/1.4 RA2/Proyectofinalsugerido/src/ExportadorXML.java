import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;

public class ExportadorXML {

    private static final String INDENT = "  "; // Indentación para XML
    private static final String DIRECTORIO = "exportaciones";

    // Exporta reservas a formato XML
    public static boolean exportar(ArrayList<Reserva> reservas, String nombreArchivo) {
        if (reservas == null || reservas.isEmpty()) {
            System.out.println("❌ ERROR: No hay reservas para exportar.");
            return false;
        }
        if (nombreArchivo == null || nombreArchivo.trim().isEmpty()) {
            System.out.println("❌ ERROR: El nombre del archivo no puede estar vacío.");
            return false;
        }

        File dir = new File(DIRECTORIO);
        if (!dir.exists()) dir.mkdir();

        String rutaCompleta = DIRECTORIO + File.separator + nombreArchivo + ".xml";
        DateTimeFormatter formatoFecha = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        // Estadísticas simples
        HashMap<String, Integer> estadoCount = new HashMap<>();
        HashMap<String, Double> tipoIngresos = new HashMap<>();
        HashMap<String, Integer> tipoReservas = new HashMap<>();
        int totalNoches = 0;
        double ingresosTotal = 0;

        for (Reserva r : reservas) {
            estadoCount.put(r.getEstado(), estadoCount.getOrDefault(r.getEstado(), 0) + 1);
            String tipo = r.getHabitacion().getTipo();
            tipoReservas.put(tipo, tipoReservas.getOrDefault(tipo, 0) + 1);
            tipoIngresos.put(tipo, tipoIngresos.getOrDefault(tipo, 0.0) + r.getPrecioTotal());
            totalNoches += r.getNoches();
            ingresosTotal += r.getPrecioTotal();
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(rutaCompleta))) {
            writer.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
            writer.write("<hotel>\n");

            // Información general
            writer.write(INDENT + "<informacion>\n");
            writer.write(INDENT + INDENT + "<nombre>Hotel Paradise</nombre>\n");
            writer.write(INDENT + INDENT + "<fecha>" + LocalDate.now().format(formatoFecha) + "</fecha>\n");
            writer.write(INDENT + "</informacion>\n");

            // Reservas
            writer.write(INDENT + "<reservas totalReservas=\"" + reservas.size() + "\">\n");
            for (Reserva r : reservas) {
                writer.write(INDENT + INDENT + "<reserva id=\"" + r.getId() + "\" estado=\"" + escaparXML(r.getEstado()) + "\">\n");

                // Cliente
                writer.write(INDENT + INDENT + INDENT + "<cliente>\n");
                writer.write(INDENT + INDENT + INDENT + INDENT + "<id>" + r.getCliente().getId() + "</id>\n");
                writer.write(INDENT + INDENT + INDENT + INDENT + "<nombre>" + escaparXML(r.getCliente().getNombre()) + "</nombre>\n");
                writer.write(INDENT + INDENT + INDENT + INDENT + "<email>" + escaparXML(r.getCliente().getEmail()) + "</email>\n");
                writer.write(INDENT + INDENT + INDENT + INDENT + "<telefono>" + escaparXML(r.getCliente().getTelefono()) + "</telefono>\n");
                writer.write(INDENT + INDENT + INDENT + "</cliente>\n");

                // Habitacion
                writer.write(INDENT + INDENT + INDENT + "<habitacion numero=\"" + r.getHabitacion().getNumero() +
                        "\" tipo=\"" + escaparXML(r.getHabitacion().getTipo()) + "\">\n");
                writer.write(INDENT + INDENT + INDENT + INDENT + "<precioPorNoche>" + r.getHabitacion().getPrecioPorNoche() + "</precioPorNoche>\n");
                writer.write(INDENT + INDENT + INDENT + INDENT + "<disponible>" + r.getHabitacion().isDisponible() + "</disponible>\n");
                writer.write(INDENT + INDENT + INDENT + "</habitacion>\n");

                // Fechas
                writer.write(INDENT + INDENT + INDENT + "<fechas>\n");
                writer.write(INDENT + INDENT + INDENT + INDENT + "<entrada>" + r.getFechaEntrada().format(formatoFecha) + "</entrada>\n");
                writer.write(INDENT + INDENT + INDENT + INDENT + "<salida>" + r.getFechaSalida().format(formatoFecha) + "</salida>\n");
                writer.write(INDENT + INDENT + INDENT + INDENT + "<noches>" + r.getNoches() + "</noches>\n");
                writer.write(INDENT + INDENT + INDENT + "</fechas>\n");

                writer.write(INDENT + INDENT + "</reserva>\n");
            }
            writer.write(INDENT + "</reservas>\n");

            writer.write("</hotel>\n");
            System.out.println("✅ Exportación XML de reservas completada: " + rutaCompleta);
            return true;

        } catch (IOException ex) {
            System.out.println("❌ ERROR al escribir XML: " + ex.getMessage());
            return false;
        }
    }

    // Escapar caracteres especiales para XML
    private static String escaparXML(String texto) {
        if (texto == null) return "";
        return texto.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;").replace("'", "&apos;");
    }
}
